<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$data['pendapatan'] = $this->db->get('pkb')->result_array();
		$this->load->view('dashboard', $data);
	}
	public function edit()
	{
		$data['pendapatan'] = $this->db->get('pkb')->result_array();
		$this->load->view('dashboard', $data);
	}
	public function edit_data($id)
	{
		$data = array(
			'jenis_kendaraan' => $this->input->post('jk'),
			'merk' => $this->input->post('merk'),
			'tahun_pembuatan' => $this->input->post('tp'),
			'nr_nm' => $this->input->post('nr_nm')
		);
		$where = array('id' => $id);
		$this->db->update('pkb', $data, $where);
		redirect('welcome');
	}
	public function hapus($id)
	{
		$where = array('id' => $id);
		$this->db->where($where);
		$this->db->delete('pkb');
		redirect('welcome');
	}
	function tambah_data()
	{
		$data = array(
			'jenis_kendaraan' => $this->input->post('jk'),
			'merk' => $this->input->post('merk'),
			'tahun_pembuatan' => $this->input->post('tp'),
			'nr_nm' => $this->input->post('nr_nm')
		);
		$this->db->insert('pkb', $data);
		redirect('welcome');
	}
}
