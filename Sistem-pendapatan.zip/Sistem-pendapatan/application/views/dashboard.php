<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Sistem Informasi Pendapatan</title>
    <!-- Favicon-->
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php base_url() ?>assets/css/styles.css" rel="stylesheet" />
    <!-- Font Awesome-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body>
    <!-- Responsive navbar-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">SI-PENDAPATAN</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link active" aria-current="page" href="#">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#">Link</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Dropdown</a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Action</a></li>
                            <li><a class="dropdown-item" href="#">Another action</a></li>
                            <li>
                                <hr class="dropdown-divider" />
                            </li>
                            <li><a class="dropdown-item" href="#">Something else here</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Page content-->
    <div class="container">
        <div class="text-center mt-5">
            <h1>Data Pajak Kendaraan</h1>
            <p class="lead"></p>
            <button type="button" class="btn btn-primary float-left mb-2" data-toggle="modal" data-target="#tambah"><i class="fas fa-plus"></i>Tambah data</button>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Jenis Kendaraan</th>
                        <th scope="col">Merk</th>
                        <th scope="col">Tahun Pembuatan</th>
                        <th scope="col">Nomor Rangka / Nomor Mesin</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $n = 1;
                    foreach ($pendapatan as $pkb) : ?>
                        <tr>
                            <td><?= $n++ ?></td>
                            <td><?= $pkb['jenis_kendaraan'] ?></td>
                            <td><?= $pkb['merk'] ?></td>
                            <td><?= $pkb['tahun_pembuatan'] ?></td>
                            <td><?= $pkb['nr_nm'] ?></td>
                            <td>
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#detail-pendapatan<?= $pkb['id'] ?>"><i class="fas fa-eye"></i></button>
                                <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#edit-pendapatan<?= $pkb['id'] ?>"><i class="fas fa-edit"></i></button>
                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#hapus<?= $pkb['id'] ?>"><i class="fas fa-trash"></i></button>
                            </td>
                        </tr>
                    <?php endforeach ?>

                </tbody>
            </table>
        </div>
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
    <!-- Core theme JS-->
    <script src="<?php base_url() ?>assets/js/scripts.js"></script>
</body>

</html>


<div class="modal fade-in" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data Pajak Kendaraan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('index.php/welcome/tambah_data') ?>" method="POST">
                    <div class="form-group">
                        <input type="text" class="form-control" name="jk" placeholder="masukan data jenis kendaraan">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="merk" placeholder="masukan merk kendaraan">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="tp" placeholder="masukan tahun pembuatan">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="nr_nm" placeholder="masukan nomor rangka / nomor mesin ">
                    </div>
                    <center>
                        <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-success">Tambah</button>
                    </center>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<?php foreach ($pendapatan as $pkb) { ?>
    <div class="modal fade" id="detail-pendapatan<?= $pkb['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Detail Pajak Kendaraan <?= $pkb['nr_nm'] ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col">
                            <p>Jenis Kendaraan </p>
                            <p>Merk Kendaraan </p>
                            <p>Tahun pembuatan</p>
                            <p>Nomor Rangka / Nomor Mesin </p>
                        </div>
                        <div class="col-sm-1">
                            <p>:</p>
                            <p>:</p>
                            <p>:</p>
                            <p>:</p>
                        </div>
                        <div class="col float-left">
                            <p><?= $pkb['jenis_kendaraan'] ?></p>
                            <p><?= $pkb['merk'] ?></p>
                            <p><?= $pkb['tahun_pembuatan'] ?></p>
                            <p><?= $pkb['nr_nm'] ?></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-block btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php } ?>

<?php foreach ($pendapatan as $pkb) { ?>
    <div class="modal fade-in" id="edit-pendapatan<?= $pkb['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Data Pajak Kendaraan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('index.php/welcome/edit_data/' . $pkb['id']) ?>" method="POST">
                        <div class="form-group">
                            <input type="text" class="form-control" name="jk" value="<?= $pkb['jenis_kendaraan'] ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="merk" value="<?= $pkb['merk'] ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="tp" value="<?= $pkb['tahun_pembuatan'] ?>">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" name="nr_nm" value="<?= $pkb['nr_nm'] ?>">
                        </div>
                        <center>
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-warning">Ubah</button>
                        </center>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php } ?>


<?php foreach ($pendapatan as $pkb) { ?>
    <div class="modal fade-in" id="hapus<?= $pkb['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <center>
                        <h4>Apakah anda yakin ingin menghapus file ini ?</h4>
                        <p class="font-italic">file yang telah dihapus tidak dpat dikembalikan</p>

                        <form action="<?= base_url('index.php/welcome/hapus/' . $pkb['id']) ?>">'
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </center>

                </div>
            </div>
        </div>
    </div>
<?php } ?>